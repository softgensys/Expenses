<?php//This is For the NAVIGATION for the pages after the login pages.(FOR MENU)?>
<a href="dashboard.php">DASHBOARD</a>
<a href="category.php">CATEGORY</a>
<a href="expenses.php">EXPENSES</a>
<a href="reports.php">REPORTS</a>
<a href="logout.php">LOGOUT</a>