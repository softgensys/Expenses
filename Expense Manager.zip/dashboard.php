<?php
include('header.php');
CheckUser();
$trans_type="";
?>
  <!-- MAIN CONTENT-->
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <script>
    $(document).ready(function() {
        
        $('#trans_type').change(function() {
            $('#trans_type_form').submit();
        });
    });
    </script>

    <div class="main-content">
                <div class="section__content section__content--p30">
                    <h2>DASHBOARD</h2><br/>
                    <div class="row form-group">
                                    <div class="col col-md-4">                                        
                                    </div>
                    <form id="trans_type_form" method="post" action="">
                                    <div class="col col-md-3">
                                        <label for="trans_type" class="form-control-label"><b>Type</b></label>
                                    </div>
                                    <div class="col-12 col-md-12">
                                        <select name="trans_type" id="trans_type" class="form-control">
                                            <option value="0">Select Income/Expense</option>
                                            <option value="Income" <?php if (isset($_POST['trans_type']) && $_POST['trans_type'] == 'Income') echo 'selected'; ?>>Income</option>
                                            <option value="Expense" <?php if (isset($_POST['trans_type']) && $_POST['trans_type'] == 'Expense') echo 'selected'; ?>>Expense</option>
                                        </select>
                                    </div>
                                </form>
                                </div><br/>
                                <?php
                                    // Get the selected trans_type value
                                    $trans_type = isset($_POST['trans_type']) ? $_POST['trans_type'] : '';
                                ?>
                    <div class="container-fluid">
                        
                        <div class="row m-t-25">
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                                                                    
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('today',$trans_type) ?></h2>
                                                <span>Today's Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('yesterday') ?></h2>
                                                <span>Yesterday's Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('week') ?></h2>
                                                <span>Week's Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('month') ?></h2>
                                                <span>Month's Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('year') ?></h2>
                                                <span>Year's Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-lg-3">
                                <div class="overview-item overview-item--c1">
                                    <div class="overview__inner">
                                        <div class="overview-box clearfix">
                                            
                                            <div class="text">
                                                <h2><?php echo getDashboardExpense('total') ?></h2>
                                                <span>My Total Expenses</span>
                                            </div>
                                        </div>
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                                                                           
                    </div>
                </div>
    </div>
    <!-- END MAIN CONTENT-->


<?php
include('footer.php');
?>